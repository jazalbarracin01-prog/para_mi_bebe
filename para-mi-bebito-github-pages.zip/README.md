# Para mi bebito 💌

Este proyecto está preparado para GitHub Pages.

## Publicarlo
1. Crear un repositorio nuevo en GitHub.
2. Subir `index.html` a la raíz del repositorio.
3. Ir a Settings → Pages.
4. En Build and deployment elegir `Deploy from a branch`.
5. Seleccionar `main` y `/ (root)`.
6. Guardar y esperar a que GitHub Pages publique el sitio.

La página de inicio es `index.html`.
